// main.cpp
#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "tiny_obj_loader.h"  // pastikan file ini berada di folder include
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

// Struktur Model untuk menyimpan VAO, VBO, EBO dan jumlah indeks
struct Model {
    unsigned int VAO;
    unsigned int VBO;
    unsigned int EBO;
    size_t indexCount;
    glm::mat4 modelMatrix; // transformasi individu untuk setiap model
};

// Global untuk mode kamera
bool perspectiveMode = true;

// Fungsi pembantu: Membaca isi file teks (shader source)
std::string readFile(const std::string& filePath) {
    std::ifstream file(filePath);
    if(!file.is_open()){
        std::cerr << "Gagal membuka file: " << filePath << std::endl;
        return "";
    }
    std::stringstream ss;
    ss << file.rdbuf();
    return ss.str();
}

// Fungsi untuk compile shader
unsigned int compileShader(const char* source, GLenum shaderType) {
    unsigned int shader = glCreateShader(shaderType);
    glShaderSource(shader, 1, &source, nullptr);
    glCompileShader(shader);
    // Cek error
    int success;
    char infoLog[512];
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if(!success){
        glGetShaderInfoLog(shader, 512, nullptr, infoLog);
        std::cerr << "Error compiling shader: " << infoLog << std::endl;
    }
    return shader;
}

// Fungsi untuk membuat shader program dari file
unsigned int createShaderProgram(const std::string& vertexPath, const std::string& fragmentPath) {
    std::string vertexCode = readFile(vertexPath);
    std::string fragmentCode = readFile(fragmentPath);
    unsigned int vertexShader = compileShader(vertexCode.c_str(), GL_VERTEX_SHADER);
    unsigned int fragmentShader = compileShader(fragmentCode.c_str(), GL_FRAGMENT_SHADER);
    
    unsigned int shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);
    
    // Cek linking
    int success;
    char infoLog[512];
    glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
    if(!success){
        glGetProgramInfoLog(shaderProgram, 512, nullptr, infoLog);
        std::cerr << "Error linking shader program: " << infoLog << std::endl;
    }
    
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);
    
    return shaderProgram;
}

// Fungsi untuk load model .obj menggunakan tinyobjloader
bool loadModel(const std::string& path, Model &model) {
    tinyobj::attrib_t attrib;
    std::vector<tinyobj::shape_t> shapes;
    std::vector<tinyobj::material_t> materials;
    std::string warn, err;
    bool ret = tinyobj::LoadObj(&attrib, &shapes, &materials, &warn, &err, path.c_str());
    if(!warn.empty()){
        std::cout << "Warning: " << warn << std::endl;
    }
    if(!err.empty()){
        std::cerr << "Error: " << err << std::endl;
    }
    if(!ret){
        std::cerr << "Gagal memuat model: " << path << std::endl;
        return false;
    }
    
    // Kumpulkan data vertex: posisi (3) dan normal (3)
    std::vector<float> vertices;
    std::vector<unsigned int> indices;
    
    // Loop per shape
    for (const auto& shape : shapes) {
        for (const auto& index : shape.mesh.indices) {
            // Posisi
            float vx = attrib.vertices[3 * index.vertex_index + 0];
            float vy = attrib.vertices[3 * index.vertex_index + 1];
            float vz = attrib.vertices[3 * index.vertex_index + 2];
            // Normal (periksa apakah ada normal)
            float nx = 0.0f, ny = 0.0f, nz = 0.0f;
            if (!attrib.normals.empty() && index.normal_index >= 0) {
                nx = attrib.normals[3 * index.normal_index + 0];
                ny = attrib.normals[3 * index.normal_index + 1];
                nz = attrib.normals[3 * index.normal_index + 2];
            }
            vertices.push_back(vx);
            vertices.push_back(vy);
            vertices.push_back(vz);
            vertices.push_back(nx);
            vertices.push_back(ny);
            vertices.push_back(nz);
            indices.push_back(static_cast<unsigned int>(indices.size()));
        }
    }
    
    model.indexCount = indices.size();
    
    // Setup VAO, VBO, dan EBO
    glGenVertexArrays(1, &model.VAO);
    glGenBuffers(1, &model.VBO);
    glGenBuffers(1, &model.EBO);
    
    glBindVertexArray(model.VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER, model.VBO);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), vertices.data(), GL_STATIC_DRAW);
    
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, model.EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), indices.data(), GL_STATIC_DRAW);
    
    // Atribut posisi: 3 float offset 0
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    
    // Atribut normal: 3 float dimulai dari offset 3 * sizeof(float)
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    
    glBindVertexArray(0);
    
    return true;
}

// Callback untuk mengubah viewport
void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}

// Proses input: switching kamera
void processInput(GLFWwindow* window) {
    if(glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
    
    // Tekan "1" untuk kamera perspektif
    if(glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS)
        perspectiveMode = true;
    // Tekan "2" untuk kamera ortogonal
    if(glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS)
        perspectiveMode = false;
}

int main() {
    // Inisialisasi GLFW
    if(!glfwInit()){
        std::cerr << "GLFW gagal diinisialisasi!" << std::endl;
        return -1;
    }
    
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    
    // Buat window
    GLFWwindow* window = glfwCreateWindow(800, 600, "Tugas Teknik Visualisasi", nullptr, nullptr);
    if(window == nullptr){
        std::cerr << "Gagal membuat GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    
    // Inisialisasi GLAD
    if(!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)){
        std::cerr << "Gagal menginisialisasi GLAD" << std::endl;
        return -1;
    }
    
    // Aktifkan depth test
    glEnable(GL_DEPTH_TEST);
    
    // Buat shader program (file shader ada di folder "shader/")
    unsigned int shaderProgram = createShaderProgram("shader/vertex.vs", "shader/fragment.fs");
    
    // Load 3 model .obj
    std::vector<Model> models;
    std::vector<std::string> modelPaths = {
        "model/model1.obj",
        "model/model2.obj",
        "model/model3.obj"
    };
    // Tentukan transformasi model agar tidak saling bertumpuk
    std::vector<glm::vec3> translations = {
        glm::vec3(-2.0f, 0.0f, 0.0f),
        glm::vec3( 0.0f, 0.0f, 0.0f),
        glm::vec3( 2.0f, 0.0f, 0.0f)
    };
    
    for (size_t i = 0; i < modelPaths.size(); ++i) {
        Model mdl;
        if(!loadModel(modelPaths[i], mdl)){
            std::cerr << "Model " << modelPaths[i] << " gagal dimuat." << std::endl;
            continue;
        }
        // Set transformasi model
        mdl.modelMatrix = glm::translate(glm::mat4(1.0f), translations[i]);
        models.push_back(mdl);
    }
    
    // Tentukan posisi cahaya dan warna
    glm::vec3 lightPos(0.0f, 5.0f, 5.0f);
    glm::vec3 lightColor(1.0f, 1.0f, 1.0f);
    glm::vec3 objectColor(0.7f, 0.5f, 0.3f);
    
    // Loop render
    while(!glfwWindowShouldClose(window)){
        processInput(window);
        
        // Bersihkan buffer
        glClearColor(0.1f, 0.1f, 0.15f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        // Gunakan shader program
        glUseProgram(shaderProgram);
        
        // Set uniform cahaya
        glUniform3fv(glGetUniformLocation(shaderProgram, "lightPos"), 1, glm::value_ptr(lightPos));
        // Kamera: posisinya di (0,0,10)
        glm::vec3 camPos(0.0f, 0.0f, 10.0f);
        glUniform3fv(glGetUniformLocation(shaderProgram, "viewPos"), 1, glm::value_ptr(camPos));
        glUniform3fv(glGetUniformLocation(shaderProgram, "lightColor"), 1, glm::value_ptr(lightColor));
        glUniform3fv(glGetUniformLocation(shaderProgram, "objectColor"), 1, glm::value_ptr(objectColor));
        
        // Set view matrix berdasarkan mode kamera
        glm::mat4 view;
        if(perspectiveMode)
            view = glm::lookAt(camPos, glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        else
            // Untuk kamera ortogonal gunakan posisi dan arah yang sama
            view = glm::lookAt(camPos, glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        
        // Set projection matrix
        glm::mat4 projection;
        if(perspectiveMode)
            projection = glm::perspective(glm::radians(45.0f), 800.f/600.f, 0.1f, 100.0f);
        else
            projection = glm::ortho(-5.0f, 5.0f, -4.0f, 4.0f, 0.1f, 100.0f);
        
        // Kirim uniform view dan projection ke shader
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "view"), 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, glm::value_ptr(projection));
        
        // Render tiap model
        for (const auto &mdl : models) {
            glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(mdl.modelMatrix));
            glBindVertexArray(mdl.VAO);
            glDrawElements(GL_TRIANGLES, mdl.indexCount, GL_UNSIGNED_INT, 0);
        }
        
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    
    // Cleanup semua VAO/VBO/EBO
    for (const auto &mdl : models) {
        glDeleteVertexArrays(1, &mdl.VAO);
        glDeleteBuffers(1, &mdl.VBO);
        glDeleteBuffers(1, &mdl.EBO);
    }
    glDeleteProgram(shaderProgram);
    
    glfwTerminate();
    return 0;
}